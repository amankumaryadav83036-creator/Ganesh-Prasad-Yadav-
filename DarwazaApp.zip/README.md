# दरवाज़ा-खिड़की-शीशा App (Hindi)
All-in-one solution to design, estimate and order custom doors, windows & glass panels.

## Modules
- Web (React)
- Android (Expo/React Native)
- Backend (Node.js + Express + SQLite)

## Run Instructions
1. cd backend && npm install && npm start
2. cd web && npm install && npm start
3. cd mobile && npm install && expo start

Made with ❤️ in India.
