import React, {useState} from 'react';
import { SafeAreaView, View, Text, TextInput, Button, Alert } from 'react-native';
import { Picker } from '@react-native-picker/picker';

export default function App(){
  const [lang,setLang] = useState('hi')
  const [type,setType] = useState('darwaza')
  const [height,setHeight] = useState('')
  const [width,setWidth] = useState('')

  const estimate = () => {
    const area = (Number(height)/100)*(Number(width)/100) || 0
    const materialRate = 1500
    const material = area * materialRate
    const labour = 500
    const gst = 0.18 * (material + labour)
    return {material, labour, gst, total: material+labour+gst}
  }

  return (
    <SafeAreaView style={{flex:1,padding:16}}>
      <View style={{flexDirection:'row',justifyContent:'space-between',alignItems:'center'}}>
        <Text style={{fontSize:20}}>{lang==='hi'?'दरवाज़ा/खिड़की ऐप':'Door/Window App'}</Text>
        <Button title={lang==='hi'?'English':'हिंदी'} onPress={()=>setLang(lang==='hi'?'en':'hi')} />
      </View>
      <View style={{marginTop:20}}>
        <Text>प्रकार</Text>
        <Picker selectedValue={type} onValueChange={(v)=>setType(v)}>
          <Picker.Item label="दरवाज़ा" value="darwaza" />
          <Picker.Item label="खिड़की" value="khidki" />
          <Picker.Item label="शीशा" value="sheesha" />
        </Picker>
        <TextInput placeholder="ऊँचाई (cm)" keyboardType='numeric' value={height} onChangeText={setHeight} style={{borderWidth:1,padding:8,marginTop:8}} />
        <TextInput placeholder="चौड़ाई (cm)" keyboardType='numeric' value={width} onChangeText={setWidth} style={{borderWidth:1,padding:8,marginTop:8}} />
        <Button title="तुरंत अनुमान देखें" onPress={()=>Alert.alert('Estimate', JSON.stringify(estimate()))} />
      </View>
    </SafeAreaView>
  )
}
