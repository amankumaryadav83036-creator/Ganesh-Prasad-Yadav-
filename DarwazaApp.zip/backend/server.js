const express = require('express')
const multer = require('multer')
const path = require('path')
const fs = require('fs')
const sqlite3 = require('sqlite3').verbose()
const bodyParser = require('body-parser')
const cors = require('cors')

// Setup
const app = express()
app.use(cors())
app.use(bodyParser.json())
app.use('/uploads', express.static(path.join(__dirname,'uploads')))

// Storage for uploads
const uploadDir = path.join(__dirname,'uploads')
if(!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir)
const storage = multer.diskStorage({
  destination: (req,file,cb)=> cb(null,uploadDir),
  filename: (req,file,cb)=> cb(null, Date.now() + '-' + file.originalname)
})
const upload = multer({storage})

// SQLite DB
const dbFile = path.join(__dirname,'app.db')
const db = new sqlite3.Database(dbFile)

// Init tables
db.serialize(()=>{
  db.run(`CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    phone TEXT,
    address TEXT,
    type TEXT,
    measurements TEXT,
    material TEXT,
    glass_type TEXT,
    images TEXT,
    estimate REAL,
    status TEXT DEFAULT 'Placed',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`)
})

// Simple estimate function
function calculateEstimate({height_cm, width_cm, material}){
  const area_m2 = ((Number(height_cm)||0)/100) * ((Number(width_cm)||0)/100)
  let materialRate = 1500 // default per m2
  if(material === 'aluminium') materialRate = 2000
  if(material === 'wood') materialRate = 1800
  if(material === 'upvc') materialRate = 1600
  const materialCost = area_m2 * materialRate
  const labour = 500
  const transport = 100
  const gst = 0.18 * (materialCost + labour)
  const total = materialCost + labour + transport + gst
  return {area_m2, materialCost, labour, transport, gst, total}
}

// Routes
app.get('/', (req,res)=> res.send('Darwaza API running'))

// Estimate endpoint
app.post('/api/estimate', (req,res)=>{
  try{
    const {height_cm,width_cm,material} = req.body
    const result = calculateEstimate({height_cm,width_cm,material})
    return res.json({success:true, data:result})
  }catch(err){
    console.error(err)
    return res.status(500).json({success:false, error:err.message})
  }
})

// Upload image
app.post('/api/upload', upload.array('images',5), (req,res)=>{
  const files = req.files.map(f => ({filename: f.filename, url: `/uploads/${f.filename}`}))
  res.json({success:true, files})
})

// Create order
app.post('/api/orders', (req,res)=>{
  const {name,phone,address,type,measurements,material,glass_type,images,estimate} = req.body
  const stmt = db.prepare(`INSERT INTO orders (name,phone,address,type,measurements,material,glass_type,images,estimate) VALUES (?,?,?,?,?,?,?,?,?)`)
  stmt.run(name,phone,address,type,JSON.stringify(measurements),material,glass_type,JSON.stringify(images),estimate, function(err){
    if(err) return res.status(500).json({success:false,error:err.message})
    return res.json({success:true, order_id:this.lastID})
  })
})

// Get order
app.get('/api/orders/:id', (req,res)=>{
  const id = req.params.id
  db.get('SELECT * FROM orders WHERE id = ?', [id], (err,row)=>{
    if(err) return res.status(500).json({success:false,error:err.message})
    if(!row) return res.status(404).json({success:false,error:'Order not found'})
    row.measurements = JSON.parse(row.measurements||'{}')
    row.images = JSON.parse(row.images||'[]')
    res.json({success:true, order:row})
  })
})

// List orders (simple)
app.get('/api/orders', (req,res)=>{
  db.all('SELECT id,name,phone,type,estimate,status,created_at FROM orders ORDER BY created_at DESC', [], (err,rows)=>{
    if(err) return res.status(500).json({success:false,error:err.message})
    res.json({success:true, orders:rows})
  })
})

// Update order status (admin/seller)
app.post('/api/orders/:id/status', (req,res)=>{
  const id = req.params.id
  const {status} = req.body
  db.run('UPDATE orders SET status = ? WHERE id = ?', [status,id], function(err){
    if(err) return res.status(500).json({success:false,error:err.message})
    res.json({success:true})
  })
})

const PORT = process.env.PORT || 4000
app.listen(PORT, ()=>console.log('Server running on',PORT))
