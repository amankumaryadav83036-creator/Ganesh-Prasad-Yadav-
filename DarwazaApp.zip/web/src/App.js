import React, {useState} from 'react';

function App() {
  const [lang,setLang] = useState('hi')
  const [type,setType] = useState('darwaza')
  const [height,setHeight] = useState('')
  const [width,setWidth] = useState('')

  const estimate = () => {
    const area = (Number(height)/100)*(Number(width)/100) || 0
    const materialRate = 1500 // per m2 (example)
    const material = area * materialRate
    const labour = 500
    const gst = 0.18 * (material + labour)
    return {material, labour, gst, total: material+labour+gst}
  }
  const res = estimate()

  return (
    <div style={{padding:20,fontFamily:'Arial, sans-serif'}}>
      <header style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <h1>{lang==='hi'? 'दरवाज़ा/खिड़की ऐप' : 'Door/Window App'}</h1>
        <button onClick={()=>setLang(lang==='hi'?'en':'hi')}>{lang==='hi'? 'English' : 'हिंदी'}</button>
      </header>
      <main style={{marginTop:20}}>
        <div>
          <label>प्रकार</label>
          <select value={type} onChange={e=>setType(e.target.value)}>
            <option value="darwaza">दरवाज़ा</option>
            <option value="khidki">खिड़की</option>
            <option value="sheesha">शीशा</option>
          </select>
        </div>
        <div style={{marginTop:10}}>
          <input placeholder="ऊँचाई (cm)" value={height} onChange={e=>setHeight(e.target.value)} />
          <input placeholder="चौड़ाई (cm)" value={width} onChange={e=>setWidth(e.target.value)} style={{marginLeft:8}}/>
        </div>
        <div style={{marginTop:12}}>
          <button onClick={()=>alert(JSON.stringify(res))}>तुरंत अनुमान देखें</button>
        </div>
      </main>
    </div>
  );
}

export default App;
